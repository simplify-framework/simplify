exports.handler = function (event, context) {
  console.log("EVENT: ".concat(JSON.stringify(event)));
};